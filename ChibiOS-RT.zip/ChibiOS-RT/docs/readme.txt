*** Documentation build procedure ***

The following software must be installed:
- Doxygen 1.7.4 or later.
- Graphviz 2.26.3 or later. The ./bin directory must be specified in the path
  in order to make Graphviz accessible by Doxygen.

Build procedure:
- Run Doxywizard.
- Load ./docs/Doxyfile_html or ./docs/Doxyfile_chm from Doxywizard.
- Start.
